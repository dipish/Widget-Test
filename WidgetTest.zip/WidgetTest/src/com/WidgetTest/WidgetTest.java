package com.WidgetTest;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

public class WidgetTest extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        final Button button=(Button)findViewById(R.id.button);
        
       	final CheckBox checkBox0 = (CheckBox)findViewById(R.id.checkBox0);
       	
       	final CheckBox checkBox1 = (CheckBox)findViewById(R.id.checkBox1);

        checkBox0.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				
			boolean b = checkBox0.isChecked();
				String s = b ? "SUV is Selected" : "Unchecked";
				Toast.makeText(WidgetTest.this, s, Toast.LENGTH_SHORT).show();
			}
		});
        
        checkBox1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				
			boolean b = checkBox0.isChecked();
				String s = b ? "Coupe is Selected" : "Unchecked";
				Toast.makeText(WidgetTest.this, s, Toast.LENGTH_SHORT).show();
			}
		});
        
        
        final OnClickListener radioListener = new OnClickListener() {
			public void onClick(View v) {
				RadioButton radioButton = (RadioButton)v;
				Toast.makeText(WidgetTest.this, radioButton.getText(), Toast.LENGTH_SHORT).show();
			}
		};

		final RadioButton radioButton0 = (RadioButton)findViewById(R.id.radioButton0);
		radioButton0.setOnClickListener((android.view.View.OnClickListener) radioListener);
		
		final RadioButton radioButton1 = (RadioButton)findViewById(R.id.radioButton1);
		radioButton1.setOnClickListener((android.view.View.OnClickListener) radioListener);

		final RadioButton radioButton2 = (RadioButton)findViewById(R.id.radioButton2);
		radioButton2.setOnClickListener((android.view.View.OnClickListener) radioListener);
		
		button.setOnClickListener(new OnClickListener()
        { public void onClick(View v){
        	Toast.makeText(WidgetTest.this, "Button pressed", Toast.LENGTH_LONG).show();
        	//Toast.makeText(WidgetTest.this, radioButton.getText(), Toast.LENGTH_LONG).show();
       	// display("button pressed");
        }

       
        });
	    Spinner spinner = (Spinner) findViewById(R.id.spinner);   
	    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.car_array, android.R.layout.simple_spinner_item);   
	    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    spinner.setAdapter(adapter);
		


    }
}